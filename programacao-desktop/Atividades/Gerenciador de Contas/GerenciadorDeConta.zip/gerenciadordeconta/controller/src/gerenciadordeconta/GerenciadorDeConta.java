/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gerenciadordeconta;

import controller.Main;
import javax.swing.JOptionPane;
import model.Conta;


public class GerenciadorDeConta extends Main {

    private Conta conta[] = new Conta[100];

    public String listarContas() {
        String result = "";
        for (int i = 0; i < conta.length; i++) {
            GerenciadorDeConta instance = new GerenciadorDeConta();
            result = instance.listarContas();
        }
        return result;

    }

    public void removerConta(int numeroDaConta) {
        for (int i = 0; i < conta.length; i++) {
            if (conta[i].getNumero() == numeroDaConta) {
                int numero = 0;
                numero = conta[i].getNumero();
            }
        }
    }

    public boolean atualizarNomeDoTitular(int numeroDaConta, String novoNomeDoTitular) {
        for (int i = 0; i < conta.length; i++) {
            if ((conta[i].getNumero()) == numeroDaConta) {
                conta[i].setTitular(novoNomeDoTitular);
                JOptionPane.showMessageDialog(null, "Nome titular " + conta[i].getNumero()
                        + " Alterado.");
            }
        }
        return true;
    }

    public boolean pesquisarAgencia(int numeroDaConta) {
        for (int i = 0; i < conta.length; i++) {
            if (conta[i].getNumero() == numeroDaConta) {
                return true;
            }
        }
        return false;
    }

    public Conta criarConta(int numero, String agencia, String titular, double saldo) {

        for (int i = 0; i < conta.length; i++) {
            conta[i].setNumero(numero);
            conta[i].setAgencia(agencia);
            conta[i].setTitular(titular);
            conta[i].setSaldo(saldo);
            
            conta[i] = new Conta(numero, agencia, titular, saldo);
        }

        return null;
    }

    public double pesquisarSaldo(int numeroDaConta) {
        int i = 0;
        for (i = 0; i < conta.length; i++) {
            if (conta[i].getNumero() == numeroDaConta) {

            }
        }
        return conta[i].getSaldo();
    }
}
