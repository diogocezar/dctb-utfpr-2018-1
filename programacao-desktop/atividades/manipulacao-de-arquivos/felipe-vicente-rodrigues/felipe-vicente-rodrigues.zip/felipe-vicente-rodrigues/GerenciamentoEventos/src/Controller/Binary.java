/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Event;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author felipe
 */
public class Binary {

    private ObjectOutputStream out;

    public void openFileOutput() {
        try {
            this.out = new ObjectOutputStream(new FileOutputStream("./outBin.bin"));
        } catch (IOException e) {
            System.err.println("Error opening file.");
        }
    }

    public void addRecords(Event ev1) {
        try {
            out.writeObject(ev1);

        } catch (IOException e) {
            System.err.println("Error. " + e);
        }
    }

    public void closeFile() {
        try {
            if (this.out != null) {
                this.out.close();
            }
        } catch (IOException e) {
            System.err.println("Error closing file.");
        }
    }

    private ObjectInputStream in;

    public void openFileInput() {
        try {
            this.in = new ObjectInputStream(new FileInputStream("./outBin.bin"));
        } catch (IOException e) {
            System.err.println("Error opening file.");
        }
    }

    public Event readRecords() {
        Event ev;

        while (true) {
            try {
                ev = (Event) in.readObject();

                return ev;

            } catch (IOException ex) {
                Logger.getLogger(Binary.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Binary.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
