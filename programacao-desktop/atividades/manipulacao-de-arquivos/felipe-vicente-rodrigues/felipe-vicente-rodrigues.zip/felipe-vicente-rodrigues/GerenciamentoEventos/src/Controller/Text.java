/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Event;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author felipe
 */
public class Text {

    public void saveText(Event ev) {

        FileWriter w = null;

        try {
            w = new FileWriter("outText.txt");
        } catch (IOException ex) {
            Logger.getLogger(Text.class.getName()).log(Level.SEVERE, null, ex);
        }

        PrintWriter out = new PrintWriter(w);

        out.println(ev.event);
        out.println(ev.equipament);
        out.println(ev.room);
        out.println(ev.local);

        out.close();

        try {
            w.close();
        } catch (IOException ex) {
            Logger.getLogger(Text.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Event showText() throws FileNotFoundException, IOException {

        Event ev;

        FileReader r = null;

        r = new FileReader("outText.txt");

        BufferedReader in = new BufferedReader(r);

        ev = new Event(in.readLine(), in.readLine(), in.readLine(), in.readLine());

        in.close();
        r.close();

        return ev;

    }
}
