MVC-DAO-Simple JAVA SWING
=========================

MVC DAO Simple java swing

ini adalah contoh project simple GUI menggunakan Java Swing dengan konsep MVC.
Project ini dibuat dengan Netbeans IDE dengan fitur CRUD menggunakan
database MySQL


![screenshoot](https://raw.githubusercontent.com/ucuptimposu/MVC-DAO-Simple-Java-Swing/master/screenshoot/1.png) 


![screenshoot](https://raw.githubusercontent.com/ucuptimposu/MVC-DAO-Simple-Java-Swing/master/screenshoot/2.png)


![screenshoot](https://raw.githubusercontent.com/ucuptimposu/MVC-DAO-Simple-Java-Swing/master/screenshoot/3.png)


semoga bermanfaat.

ucup.timposu[at]gmail[dot]com


http://timposu.com
