
package Classes;

/**
 *
 * @author Erik Lima
 */
public class Subtracao {
    public double sub(double num1, double num2){
        return num1 - num2;
    }
    
}
