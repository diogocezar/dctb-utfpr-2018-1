
package Classes;

import Telas.CalculadoraJFrame;

/**
 *
 * @author Erik Lima
 */
public class Main {
    public static void main(String args[]){
        new CalculadoraJFrame().setVisible(true);
        
     
        
   
        
    }
    
}
