
package Classes;

/**
 *
 * @author Erik Lima
 */
public class Divisao {
    public double div(double num1, double num2){
        
        return num1 / num2;
        
    }
    
}
